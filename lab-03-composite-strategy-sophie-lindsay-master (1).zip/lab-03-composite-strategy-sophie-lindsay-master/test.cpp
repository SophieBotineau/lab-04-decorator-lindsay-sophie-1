#include "main.cpp"
#include "gtest/gtest.h"

TEST(MainTest, vectorselection) {
	char* test_val[3]; test_val[0] = "./main"; test_val[1] = "vector"; test_val[2] = "selection";
	EXPECT_EQ("Container before Sort:\n28\n31\n29\n841\nContainer after Sort:\n28\n29\n31\n841\n", main(3,test_val));
}

int main2(int argv, char **argc){
	::testing::InitGoogleTest(&argv, argc);
	return RUN_ALL_TESTS();
} 
